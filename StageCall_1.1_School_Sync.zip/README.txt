STAGECALL 1.1 — PROTOTYPE SHOW CONTROL

PREVIEW / SOUND ONLY
1. Open StageCall.html in a current Chrome or Edge browser. No internet or installation required.
2. Try the sample show with GO. Select a cue in the Run show list to jump to it.
3. Program cues: set levels and colours, lighting fade, optional sound action and operator note.
4. Sound library: import local sound files. Simultaneous tracks, loop, fade and stop are supported. Sound goes to the computer's default audio output.
5. Save show stores the show in browser storage when supported. Export saves a JSON backup with cues/patch/asset references, NOT audio bytes; keep original audio and use Relink when opening on a different machine. Browser file storage can vary; keep backups.

REAL LIGHTING — OPTIONAL, EXPERIMENTAL
1. Extract all files into one folder. Install Python 3.10+ if needed (python.org). On Windows double-click Start_StageCall.bat; on macOS/Linux run python3 bridge.py from this folder. Keep the terminal open. The app opens at http://127.0.0.1:8765.
2. Connect the computer to an authorised dedicated lighting network with an Art-Net-to-DMX node or compatible fixture. Patch fixture addresses and exact channel order from their manuals. Only dimmer, RGB, D/R/G/B and R/G/B/D profiles, one 512-channel universe. No moving-head, relay, strobe, RDM, USB-DMX driver or sACN support.
3. On Output settings enter the node IPv4 and zero-based Art-Net Port-Address (0–32767), check bridge, then arm. The bridge uses manually configured unicast ArtDmx (UDP 6454) at about 25 frames/sec. No discovery, subscription management or fixture acknowledgement; not a complete Art-Net 4 implementation. Verify compatibility yourself. The bridge is bound to loopback, and stops transmitting after a 2-second missed heartbeat. Node DMX-loss behaviour determines what lights actually do. Disarm before changing the patch or loading a show.
4. Stage preview is illustrative rather than a photometric simulation. BLACKOUT sets the output intensity channels to zero, not an emergency control. Sound continues unless stopped separately. Keep independent house and emergency lighting systems, backup controls and a qualified technician. Do not rely on this prototype for a live public performance without proper testing. Background tabs/sleep can interrupt output: keep the browser foregrounded and disable sleep for rehearsal.

SHORTCUTS: Space = GO (outside forms/buttons), Esc = hold lighting fade, B = toggle lighting blackout. Previous runs the previous cue (including its sound action). Reset running order does not change lights or sound.

Local web-bridge and standalone file have separate browser storage. Export the cue file and relink audio when moving between them.

VERSION 1.1 — SCHOOL DESK SYNC (EXPERIMENTAL)
- Start the Windows launcher; select Output settings > School lighting desk · Synchronise.
- Have the technician identify the desk protocol and its sender IPv4, universe and lighting network. For Art-Net unicast, the console must send a copy to this laptop. For sACN, choose the appropriate local adapter if multicast uses a different interface. Allow inbound UDP 6454 or 5568 only on the authorised private lighting network if required. Do not change the working desk's outputs without approval.
- Connect in receive-only mode. View incoming channels; capture a fresh look as a new editable cue using the correctly patched supported fixtures. A short frame missing a patched channel cannot be captured. No automatic changes on the physical desk, no console cue-stack import/export, no full console-state synchronisation. sACN preview, terminated and synchronised streams are ignored. Input is limited to one source IP and universe; do not use multiple sACN sources sharing an IP.
- To drive lights separately, stop monitoring and follow the existing Art-Net output setup. Use a dedicated test node or a technician-managed handover; there is no automatic merging, arbitration or takeover from the console. The app does not send sACN, USB DMX, OSC or MIDI. For a desk with physical DMX only, an appropriate DMX-input-to-network interface is needed for monitoring. Confirm desk compatibility before purchasing hardware.
- Audio plays through the computer audio output; physical mixing desk connection is separate. Use an approved audio interface, mixer line input and safe gain staging. No control of the mixer's faders is implemented.
