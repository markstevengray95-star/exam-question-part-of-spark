"""StageCall local development bridge: manually addressed ArtDmx UDP sender."""
import ipaddress, json, secrets, socket, struct, threading, time, webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HOST, PORT = '127.0.0.1', 8765
TOKEN = secrets.token_urlsafe(32)
LOCK = threading.Lock()
STATE = {'armed': False, 'target': None, 'universe': 0, 'levels': bytes(512), 'last': 0.0, 'error': ''}
UDP = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

def packet(universe, levels, sequence):
    return b'Art-Net\x00' + struct.pack('<H', 0x5000) + struct.pack('>H', 14) + bytes((sequence, 0, universe & 255, (universe >> 8) & 127)) + struct.pack('>H', 512) + levels

# Input is deliberately isolated from live output. Only explicitly selected frames are captured.
INPUT = {'active': False, 'protocol': '', 'universe': 0, 'source': '', 'interface': '', 'frames': 0, 'last': 0., 'levels': b'', 'ip': '', 'error': '', 'count': 0}
RX = None
GEN = 0

def decode_frame(data, protocol):
    if protocol == 'artnet':
        if len(data) < 18 or data[:10] != b'Art-Net\x00\x00P' or int.from_bytes(data[10:12], 'big') < 14: return None
        size = int.from_bytes(data[16:18], 'big')
        if not 2 <= size <= 512 or size % 2 or len(data) != 18 + size or data[15] & 128: return None
        return (data[14] | (data[15] << 8), data[18:], '')
    if len(data) < 126 or data[:16] != b'\x00\x10\x00\x00ASC-E1.17\x00\x00\x00': return None
    if data[18:22] != b'\x00\x00\x00\x04' or data[40:44] != b'\x00\x00\x00\x02' or data[117:123] != b'\x02\xa1\x00\x00\x00\x01': return None
    if any((int.from_bytes(data[o:o+2], 'big') != (0x7000 | (len(data)-o))) for o in (16,38,115)): return None
    size = int.from_bytes(data[123:125], 'big')
    if not 2 <= size <= 513 or len(data) != 125+size or data[125] != 0 or data[112] & 0xe0 or data[109:111] != b'\x00\x00': return None
    name = data[44:108].split(b'\x00',1)[0].decode('utf-8','replace')
    return (int.from_bytes(data[113:115], 'big'), data[126:], name)

def stop_input():
    global RX, GEN
    GEN += 1
    if RX is not None:
        RX.close(); RX = None
    INPUT.update(active=False, levels=b'', last=0., count=0)

def receive_loop(sock, generation):
    while True:
        try: data, addr = sock.recvfrom(2048)
        except socket.timeout:
            with LOCK:
                if generation != GEN: return
            continue
        except OSError: return
        with LOCK:
            if generation != GEN or not INPUT['active']: return
            if addr[0] != INPUT['source']: continue
            result = decode_frame(data, INPUT['protocol'])
            if result is None or result[0] != INPUT['universe']: continue
            _, levels, name = result
            INPUT.update(levels=levels, last=time.monotonic(), frames=INPUT['frames']+1, ip=addr[0], name=name, count=len(levels))

def start_input(data):
    global RX
    if STATE['armed']: raise ValueError('Disarm live output before monitoring.')
    proto = data.get('protocol'); u = data.get('universe')
    if proto not in ('artnet','sacn') or type(u) is not int or not ((0 <= u <= 32767) if proto == 'artnet' else (1 <= u <= 63999)): raise ValueError('Invalid protocol or universe.')
    source = str(ipaddress.IPv4Address(data.get('source','')))
    if ipaddress.IPv4Address(source).is_multicast or source == '0.0.0.0': raise ValueError('Enter the desk’s unicast IPv4 address.')
    interface = str(ipaddress.IPv4Address(data.get('interface') or '0.0.0.0'))
    stop_input()
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.bind(('', 6454 if proto == 'artnet' else 5568))
        if proto == 'sacn':
            group = f'239.255.{u >> 8}.{u & 255}'
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, socket.inet_aton(group) + socket.inet_aton(interface))
        sock.settimeout(.4)
    except OSError:
        sock.close(); raise
    RX = sock
    INPUT.update(active=True, protocol=proto, universe=u, source=source, interface=interface, frames=0, last=0., levels=b'', ip='', name='', error='', count=0)
    threading.Thread(target=receive_loop, args=(sock,GEN),daemon=True).start()


def levels_from(data):
    a = data.get('levels')
    if not isinstance(a, list) or len(a) != 512 or any(type(x) is not int or not 0 <= x <= 255 for x in a):
        raise ValueError('Expected 512 integer DMX levels (0–255).')
    return bytes(a)

def transmitter():
    seq = 0
    while True:
        time.sleep(0.04)
        with LOCK:
            if not STATE['armed']:
                continue
            if time.monotonic() - STATE['last'] > 2:
                STATE.update(armed=False, error='Browser heartbeat lost; output stopped.')
                continue
            seq = seq % 255 + 1
            try:
                UDP.sendto(packet(STATE['universe'], STATE['levels'], seq), (STATE['target'], 6454))
            except OSError as e:
                STATE.update(armed=False, error=str(e))

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass
    def reply(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code); self.send_header('Content-Type', 'application/json'); self.send_header('Cache-Control', 'no-store'); self.send_header('Content-Length', str(len(body))); self.end_headers(); self.wfile.write(body)
    def valid_host(self):
        return self.headers.get('Host') in (f'127.0.0.1:{PORT}', f'localhost:{PORT}')
    def do_GET(self):
        if not self.valid_host():
            return self.reply(403, {'error':'Invalid host'})
        if self.path == '/api/input':
            with LOCK:
                age = time.monotonic()-INPUT['last'] if INPUT['last'] else None
                return self.reply(200, {**{k:v for k,v in INPUT.items() if k not in ('levels','last')}, 'age':age, 'levels':list(INPUT['levels'])})
        if self.path == '/api/status':
            with LOCK:
                return self.reply(200, {'token':TOKEN,'armed':STATE['armed'],'monitoring':INPUT['active'],'error':STATE['error']})
        if self.path in ('/', '/StageCall.html'):
            data=Path(__file__).with_name('StageCall.html').read_bytes()
            self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Cache-Control','no-store'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
        else:
            self.reply(404, {'error':'Not found'})
    def do_POST(self):
        if not self.valid_host() or self.headers.get('Origin') not in (f'http://127.0.0.1:{PORT}', f'http://localhost:{PORT}'):
            return self.reply(403, {'error':'Local same-origin requests only'})
        try:
            n=int(self.headers.get('Content-Length','0'))
            if not 0 < n <= 12000: raise ValueError('Invalid request size')
            data=json.loads(self.rfile.read(n))
            if not isinstance(data,dict) or not secrets.compare_digest(str(data.get('token','')),TOKEN):
                return self.reply(403, {'error':'Invalid bridge token'})
            with LOCK:
                if self.path == '/api/input/start':
                    start_input(data)
                elif self.path == '/api/input/stop':
                    stop_input()
                elif self.path == '/api/arm':
                    if INPUT['active']: raise ValueError('Stop desk monitoring before arming output.')
                    if STATE['armed']: raise ValueError('Output already armed; close the other session or wait for its watchdog.')
                    ip=ipaddress.IPv4Address(data['ip']); u=data['universe']
                    if not (ip.is_private or ip.is_loopback or ip in ipaddress.IPv4Network('2.0.0.0/8')) or ip.is_multicast or ip.is_unspecified or ip.packed[-1] in (0,255): raise ValueError('Use a local unicast node address (private or Art-Net 2.x).')
                    if type(u) is not int or not 0<=u<=32767: raise ValueError('Invalid Port-Address')
                    lv=levels_from(data)
                    STATE.update(armed=True,target=str(ip),universe=u,levels=lv,last=time.monotonic(),error='')
                elif self.path == '/api/frame':
                    if not STATE['armed']: raise ValueError(STATE['error'] or 'Output not armed')
                    STATE.update(levels=levels_from(data),last=time.monotonic())
                elif self.path == '/api/disarm':
                    STATE.update(armed=False,error='')
                else: return self.reply(404, {'error':'Not found'})
            self.reply(200, {'ok':True})
        except (ValueError, TypeError, KeyError) as e:
            self.reply(400, {'error':str(e)})
        except OSError:
            self.reply(500, {'error':'Network error: port in use, interface unavailable or firewall/network configuration.'})

if __name__ == '__main__':
    server=ThreadingHTTPServer((HOST,PORT),Handler)
    threading.Thread(target=transmitter,daemon=True).start()
    print(f'StageCall running at http://{HOST}:{PORT} — keep this window open. Ctrl+C to quit.')
    webbrowser.open(f'http://{HOST}:{PORT}')
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally:
        with LOCK:
            STATE['armed']=False; stop_input()
        server.server_close(); UDP.close()
